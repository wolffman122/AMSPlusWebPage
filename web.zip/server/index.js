const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

// 假设已经完成前端打包，dist 目录在 client/dist
// app.use(express.static(path.join(__dirname, '../client/amsplus/dist')));

// 2. 托管 dist 目录为静态资源
//   假设你已经在此目录下通过 Vue (CLI / Vite) 生成了打包文件
app.use(express.static(path.join(__dirname, '../client/amsplus/dist')));

// 3. 对于所有未匹配的请求路径，返回 dist/index.html
//   这样可以支持前端使用 HTML5 History 路由模式
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/amsplus/dist', '../client/amsplus/index.html'));
});

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});