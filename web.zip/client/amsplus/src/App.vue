<template>
  <div>
    <FilamentGenerator />
  </div>
</template>

<script>
import FilamentGenerator from './components/FilamentGenerator.vue'


export default {
  name: 'App',
  components: {
    FilamentGenerator
  }
}
</script>